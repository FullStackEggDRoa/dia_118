package com.egg.manos_a_la_obra_p18;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManosALaObraP18ApplicationTests {

	@Test
	void contextLoads() {
	}

}
