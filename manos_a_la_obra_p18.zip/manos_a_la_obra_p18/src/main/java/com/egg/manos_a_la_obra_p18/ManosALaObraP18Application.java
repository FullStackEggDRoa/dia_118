package com.egg.manos_a_la_obra_p18;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManosALaObraP18Application {

	public static void main(String[] args) {
		SpringApplication.run(ManosALaObraP18Application.class, args);
	}

}
